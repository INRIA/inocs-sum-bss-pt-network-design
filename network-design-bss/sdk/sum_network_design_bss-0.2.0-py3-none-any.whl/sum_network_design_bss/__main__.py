"""Entry point for `python -m demo`, and for `python -m sum_network_design_bss`
once the wheel is installed. Both hand over to :func:`demo.runner.main`."""

import sys

from .runner import main

if __name__ == "__main__":
    sys.exit(main())
