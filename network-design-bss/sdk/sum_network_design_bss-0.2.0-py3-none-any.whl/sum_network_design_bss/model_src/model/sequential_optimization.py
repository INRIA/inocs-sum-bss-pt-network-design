from model.bike_sharing_optimization import BikeSharingModel
from model.benders_optimization import BendersBikeSharingModel


def solve_sequential(network, shortest_path_solver, demand_generator, epsilon=None):
    # Stage 1: solve strategic design with zero operational budget
    model_stage1 = BikeSharingModel(
        network=network,
        shortest_path_solver=shortest_path_solver,
        demand_generator=demand_generator,
        epsilon=epsilon,
        solve_mode="sequential_stage1",
    )

    fixed_design = model_stage1.get_design_solution()

    # Stage 2: restore operational budget and optimize operations on fixed design
    model_stage2 = BikeSharingModel(
        network=network,
        shortest_path_solver=shortest_path_solver,
        demand_generator=demand_generator,
        epsilon=epsilon,
        solve_mode="sequential_stage2",
        fixed_design=fixed_design,
    )

    return model_stage1, model_stage2


def solve_benders(
    network,
    shortest_path_solver,
    demand_generator,
    epsilon=None,
    max_iter: int = 100,
    tol: float = 1e-6,
    time_limit: float = 3600.0,
    recover_integer: bool = True,
):
    """
    Solve the BSS-NDP via classical (outer) Benders decomposition.

    Parameters
    ----------
    max_iter : int
        Upper bound on Benders iterations.  Set generously (1000) so the
        algorithm has room to converge to proven optimality on realistic
        instances.
    tol : float
        Relative optimality gap used to terminate the Benders loop.  Tight
        by default (1e-6) so the Benders bound is tight enough to be
        directly comparable with the integrated MIP's optimum.
    time_limit : float
        Wall-clock budget (seconds) for the full Benders loop.  Large
        enough (2 h) that the decomposition rarely quits on the clock
        unless the instance is genuinely hard.
    recover_integer : bool
        If True, fix the design variables (ŷ, ŵ, v̂1) obtained by Benders and
        re-solve the subproblem as a MIP (via sequential_stage2) so that
        downstream code that expects a full integer solution (ExperimentHandler,
        Visualize, etc.) keeps working.
    """
    benders = BendersBikeSharingModel(
        network=network,
        shortest_path_solver=shortest_path_solver,
        demand_generator=demand_generator,
        epsilon=epsilon,
        max_iter=max_iter,
        tol=tol,
        time_limit=time_limit,
    )
    benders.solve()

    if not recover_integer:
        return benders, None

    recovered = benders.recover_integer_solution()
    return benders, recovered


def solve_alns(
    network,
    shortest_path_solver,
    demand_generator,
    epsilon: float = 0.0,
    alns_config=None,
    seed: int = 42,
    stage2_time_limit: float = 300.0,
):
    """
    Solve the BSS-PT Network Design Problem with ALNS.

    Returns
    -------
    alns_solver : ALNS
        The ALNS instance (carries best_solution, history, etc.).
    best_solution : ALNSSolution
        The best first-stage solution found.
    """
    from alns.alns import ALNS, ALNSConfig
    cfg = alns_config or ALNSConfig()
    alns_solver = ALNS(
        network=network,
        shortest_path_solver=shortest_path_solver,
        demand_generator=demand_generator,
        epsilon=epsilon,
        config=cfg,
        seed=seed,
        stage2_time_limit=stage2_time_limit,
    )
    best = alns_solver.run()
    return alns_solver, best


def optimization_model_solver(demand_generator, epsilon, network_with_bss,
                              shortest_path_solver, solve_mode="integrated"):
    """
    Dispatch between solution strategies.

    solve_mode ∈ {"integrated", "sequential", "benders", "alns"}
    """
    if solve_mode == "integrated":
        bike_sharing_model = BikeSharingModel(network_with_bss, shortest_path_solver,
                                              demand_generator, epsilon)
    elif solve_mode == "sequential":
        _stage1, bike_sharing_model = solve_sequential(
            network_with_bss,
            shortest_path_solver,
            demand_generator,
            epsilon,
        )
    elif solve_mode == "benders":
        # Benders decomposition.  For downstream compatibility (ExperimentHandler,
        # Visualize), the returned model is the integer-recovered one; the pure
        # Benders master/subproblem artefact is stashed on `.benders_artifact`.
        benders_artifact, bike_sharing_model = solve_benders(
            network_with_bss,
            shortest_path_solver,
            demand_generator,
            epsilon,
        )
        if bike_sharing_model is not None:
            bike_sharing_model.benders_artifact = benders_artifact
            bike_sharing_model.solve_mode = "benders"
        else:
            bike_sharing_model = benders_artifact  # no MIP recovery was requested
    elif solve_mode == "alns":
        # ── Step 1: ALNS metaheuristic search ────────────────────────────────
        # Find the best first-stage design (y, w, v1) using ALNS.
        # The ALNS internal oracle uses LP relaxation for speed; the solution
        # quality is only an approximation at this stage.
        import time
        t_alns_start = time.time()

        alns_solver, best_alns = solve_alns(
            network_with_bss,
            shortest_path_solver,
            demand_generator,
            epsilon,
        )
        alns_runtime = time.time() - t_alns_start

        # ── Step 2: Exact operational MIP on fixed ALNS design ───────────────
        # Fix (y, w, v1) from ALNS, then solve the full operational MIP to get
        # a true objective value comparable with the integrated Gurobi result.
        # Cap at stage2_time_limit (default 300s) — the ALNS topology is already
        # fixed so the remaining problem is much easier than the integrated MIP,
        # but ε>0 rebalancing cases can still be hard.
        design = alns_solver.export_solution_dict()   # {y, w, v1}
        stage2_time_limit = getattr(alns_solver, "stage2_time_limit", 300.0)
        bike_sharing_model = BikeSharingModel(
            network=network_with_bss,
            shortest_path_solver=shortest_path_solver,
            demand_generator=demand_generator,
            epsilon=epsilon,
            solve_mode="sequential_stage2",           # fixes y/w/v1, optimises operations
            fixed_design=design,
            time_limit=stage2_time_limit,
        )

        # ── Mark model for reporting ─────────────────────────────────────────
        # solve_mode is set AFTER the MIP solve (the MIP solve itself needs
        # "sequential_stage2" to apply _apply_fixed_design correctly).
        bike_sharing_model.solve_mode   = "alns"
        bike_sharing_model.alns_artifact = alns_solver
        bike_sharing_model.alns_runtime  = alns_runtime
    else:
        raise ValueError(
            f"Unknown solve_mode='{solve_mode}'. "
            f"Expected one of: 'integrated', 'sequential', 'benders', 'alns'."
        )
    return bike_sharing_model
