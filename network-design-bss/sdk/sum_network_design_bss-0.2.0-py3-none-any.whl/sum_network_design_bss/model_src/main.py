import sys
from itertools import product

from input_handler.demand_generator import DemandGenerator
from input_handler.grid_generator import GridGenerator
from input_handler.h3_grid_generator import H3GridGenerator
from input_handler.preprocess import preprocess
from input_handler.pt_generator import PublicTransport
from instance_builder import *
from model.bike_sharing_optimization import BikeSharingModel
from network.network_constructor import NetworkConstructor
from network.node import TransferStation, BikeStation
from output_handler.experiment import ExperimentHandler
from shortest_path.shortest_path_solver import ShortestPathSolver
from util.cost import CostParameters
from util.util import *
from output_handler.visualize import Visualize
from input_handler.instance_attribute_extracter import get_instance_attribute
from model.sequential_optimization import solve_sequential, optimization_model_solver


def main_run_single_instance(instance_config, epsilon, solve_mode="integrated",
                             verify=True):
    """
    :param instance_config:
    :param epsilon:
    :param solve_mode: "integrated", "sequential", "benders", or "alns"
    :param verify: if True and solve_mode=="integrated", run LP-oracle consistency
                   check immediately after solving (verify_oracle_vs_mip).
    :return: bike_sharing_model  (so callers can chain or compare results)
    """
    configure, demand_generator, grid_generator, public_transport, station_layout = \
        get_instance_attribute(instance_config)

    network_with_bss, shortest_path_solver = get_shortest_path_solver(grid_generator, public_transport, station_layout)

    bike_sharing_model = optimization_model_solver(demand_generator, epsilon, network_with_bss, shortest_path_solver,
                                                   solve_mode)

    # ── LP-oracle correctness verification (integrated MIP only) ────────────
    if verify and solve_mode == "integrated":
        try:
            from alns.verify import verify_oracle_vs_mip
            verify_oracle_vs_mip(
                bike_sharing_model,
                network_with_bss,
                shortest_path_solver,
                demand_generator,
                epsilon=epsilon,
                verbose=True,
            )
        except Exception as e:
            print(f"[verify] Skipped due to error: {e}")

    ExperimentHandler(bike_sharing_model, network_with_bss, configure)

    Visualize(grid_generator, public_transport, shortest_path_solver, demand_generator, bike_sharing_model)

    return bike_sharing_model, network_with_bss, shortest_path_solver, demand_generator


def main_run_alns(instance_config, epsilon=0.0, alns_config=None, seed=42):
    """
    Solve a BSS-PT instance with Adaptive Large Neighborhood Search.

    Parameters
    ----------
    instance_config : InstanceGenerator or similar
    epsilon : float
        Dispatch-cost penalty weight (default 0).
    alns_config : ALNSConfig, optional
        ALNS hyper-parameters.  If None, the defaults in ALNSConfig are used.
    seed : int
        Random seed for reproducibility.

    Returns
    -------
    alns_solver : ALNS
        Carries best_solution, history, and export_solution_dict().
    """
    from alns.alns import ALNS, ALNSConfig
    from model.sequential_optimization import solve_alns

    configure, demand_generator, grid_generator, public_transport, station_layout = \
        get_instance_attribute(instance_config)

    network_with_bss, shortest_path_solver = get_shortest_path_solver(
        grid_generator, public_transport, station_layout
    )

    cfg = alns_config or ALNSConfig()
    alns_solver, best = solve_alns(
        network=network_with_bss,
        shortest_path_solver=shortest_path_solver,
        demand_generator=demand_generator,
        epsilon=epsilon,
        alns_config=cfg,
        seed=seed,
    )

    # Save convergence history
    try:
        import os, pandas as pd
        df = alns_solver.get_convergence_df()
        out_path = os.path.join(
            os.getcwd(), "data", "output", "alns",
            f"alns_convergence_{configure}.csv"
        )
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        df.to_csv(out_path, index=False)
        print(f"Convergence log saved → {out_path}")
    except Exception as e:
        print(f"Could not save convergence log: {e}")

    return alns_solver


def main_verify_alns(instance_config, epsilon=0.0, alns_config=None, seed=42,
                     results_csv="experiment_results.csv",
                     comparison_csv="comparison_results.csv"):
    """
    Full correctness-verification pipeline:

      1. Solve the integrated MIP  → get exact optimal (y*, obj*)
      2. Run LP oracle on MIP-optimal design → must be ≥ obj* (oracle sanity)
      3. Run ALNS + stage-2 MIP   → get ALNS design + integer obj
      4. Print side-by-side quality-gap table
      5. Save both method rows to *results_csv* (standard format)
      6. Append a side-by-side comparison row to *comparison_csv*
         (appendable: safe to call in a batch loop)

    Call this to confirm the LP oracle is sound before trusting ALNS results.
    """
    from alns.verify import verify_oracle_vs_mip, compare_alns_vs_mip
    from alns.alns import ALNSConfig
    from model.sequential_optimization import solve_alns, optimization_model_solver
    from output_handler.comparison_writer import save_comparison_row

    configure, demand_generator, grid_generator, public_transport, station_layout = \
        get_instance_attribute(instance_config)

    network_with_bss, shortest_path_solver = get_shortest_path_solver(
        grid_generator, public_transport, station_layout
    )

    # ── Step 1: Integrated MIP ───────────────────────────────────────────────
    print("\n" + "=" * 72)
    print("  STEP 1 / 3 — Integrated MIP (exact optimum)")
    print("=" * 72)
    integrated_model = optimization_model_solver(
        demand_generator, epsilon, network_with_bss, shortest_path_solver,
        solve_mode="integrated",
    )

    # ── Step 2: LP-oracle consistency check on MIP-optimal design ───────────
    print("\n" + "=" * 72)
    print("  STEP 2 / 3 — LP oracle consistency check")
    print("=" * 72)
    verify_result = verify_oracle_vs_mip(
        integrated_model,
        network_with_bss,
        shortest_path_solver,
        demand_generator,
        epsilon=epsilon,
        verbose=True,
    )
    if not verify_result.get("is_consistent", False):
        print("\n[main_verify_alns]  ❌  LP oracle is INCONSISTENT — aborting ALNS step.")
        print("  Fix the oracle formulation before running ALNS.")
        return

    # ── Step 3: ALNS + stage-2 MIP ──────────────────────────────────────────
    print("\n" + "=" * 72)
    print("  STEP 3 / 3 — ALNS metaheuristic + stage-2 MIP")
    print("=" * 72)
    cfg = alns_config or ALNSConfig()
    alns_model = optimization_model_solver(
        demand_generator, epsilon, network_with_bss, shortest_path_solver,
        solve_mode="alns",
    )

    # ── Step 4: Side-by-side quality-gap table (console) ────────────────────
    compare_alns_vs_mip(
        integrated_model,
        alns_model,
        network_with_bss,
        shortest_path_solver,
        demand_generator,
        epsilon=epsilon,
    )

    # ── Step 5: Save individual method rows → experiment_results.csv ────────
    print("\n" + "=" * 72)
    print("  STEP 5 — Saving individual results to experiment_results.csv")
    print("=" * 72)
    mip_handler  = ExperimentHandler(integrated_model, network_with_bss,
                                     str(configure), output_file=results_csv)
    # Pass the Gurobi-optimal obj so quality_gap is populated for the ALNS row
    mip_ref_obj  = mip_handler.last_row.get("obj_val")
    alns_handler = ExperimentHandler(alns_model, network_with_bss,
                                     str(configure), output_file=results_csv,
                                     reference_obj=mip_ref_obj)

    # ── Step 6: Append side-by-side comparison row → comparison_results.csv ─
    print("\n" + "=" * 72)
    print("  STEP 6 — Appending comparison row to comparison_results.csv")
    print("=" * 72)
    save_comparison_row(
        mip_handler.last_row,
        alns_handler.last_row,
        output_file=comparison_csv,
    )


def main_compare_methods(instance_config, epsilon,
                         methods=("integrated", "sequential", "benders"),
                         csv_name="benders_comparison.csv"):
    """
    Solve the same instance with every method (integrated MIP, sequential two-stage,
    Benders decomposition) and print/save a side-by-side comparison table,
    following the style of benders_bss.py.
    """
    from model.benders_comparison import compare_methods, print_comparison_table, save_comparison_csv
    import os

    configure, demand_generator, grid_generator, public_transport, station_layout = \
        get_instance_attribute(instance_config)
    network_with_bss, shortest_path_solver = get_shortest_path_solver(
        grid_generator, public_transport, station_layout
    )

    result = compare_methods(
        network=network_with_bss,
        shortest_path_solver=shortest_path_solver,
        demand_generator=demand_generator,
        epsilon=epsilon,
        instance_id=str(configure),
        methods=methods,
    )
    print_comparison_table([result])
    save_comparison_csv([result], os.path.join(os.getcwd(), csv_name))
    return result


def get_shortest_path_solver(grid_generator, public_transport, station_layout):
    G, grid_centers = grid_generator.grid, grid_generator.grid_centers

    # transportation network before introducing bike stations (no distance threshold)
    network_without_bss = NetworkConstructor(G, grid_generator, public_transport,
                                             None, True, False)
    shortest_path_without_bss = ShortestPathSolver(network_without_bss.graph, 1, "before")

    # transportation network after introducing bike stations
    network_with_bss = NetworkConstructor(G, grid_generator, public_transport, station_layout, False)
    shortest_path_solver = ShortestPathSolver(network_with_bss.graph, NUM_SHORTEST_PATHS,
                                              "after", shortest_path_without_bss)
    return network_with_bss, shortest_path_solver


# def main(config_name):
#
#     configure, demand_generator, grid_generator, public_transport, station_layout = get_instance_attribute(
#         config_name)
#
#     network_with_bss, shortest_path_solver = get_shortest_path_solver(grid_generator, public_transport, station_layout)
#
#     bike_sharing_model = BikeSharingModel(network_with_bss, shortest_path_solver,
#                                           demand_generator)
#
#     ExperimentHandler(bike_sharing_model, network_with_bss, configure)
#
#     Visualize(grid_generator, public_transport, shortest_path_solver, demand_generator, bike_sharing_model)

def main(instance_config):
    configure, demand_generator, grid_generator, public_transport, station_layout = \
        get_instance_attribute(instance_config)

    network_with_bss, shortest_path_solver = get_shortest_path_solver(grid_generator, public_transport, station_layout)

    bike_sharing_model = BikeSharingModel(network_with_bss, shortest_path_solver,
                                          demand_generator)

    ExperimentHandler(bike_sharing_model, network_with_bss, configure)

    Visualize(grid_generator, public_transport, shortest_path_solver, demand_generator, bike_sharing_model)


def batch_h3_instances():
    T = 3
    seeds = [10]
    # period_weight_sets = {
    #     f"dirichlet_{s}": tuple(
    #         np.random.RandomState(s).dirichlet(np.ones(T) * 0.5)
    #     )
    #     for s in seeds
    # }
    period_weight_sets = {
        # 算了两遍原因找到了。。。
        # "dirichlet": tuple(np.random.dirichlet(np.ones(T) * 0.5)),

        **{
            f"dirichlet_{s}": tuple(
                np.random.RandomState(s).dirichlet(np.ones(T) * 0.5)
            )
            for s in seeds
        },
        # "bimodal_base": (0.4, 0.2, 0.4),

        # "bimodal_sharp": (0.45, 0.10, 0.45),
        # "bimodal_flat": (1/3, 1/3, 1/3),

        # "uniform": (1 / 3, 1 / 3, 1 / 3),
        # "unimodal_morning": (0.6, 0.2, 0.2),
        # "unimodal_evening": (0.15, 0.15, 0.7),

        # "midday_peak": (0.25, 0.50, 0.25),

        # "bimodal_skew_morning": (0.50, 0.20, 0.30),
        # "bimodal_skew_evening": (0.30, 0.20, 0.50),
        # "bimodal_extended_periods": (0.1, 0.3, 0.2, 0.3, 0.1),
    }
    total_budgets = tuple(range(80000, 100001, 20000))
    op_budget_ratios = tuple(i * 0.025 for i in range(1, 2))  # (0, 0.025, 0.05, 0.1)
    epsilon_sets = [0.04, 0.08]  # [0, 0.01, 0.04, 0.08, 0.12]
    seeds = [100]
    for weight_name, period_weights in period_weight_sets.items():
        for bud, op_ratio, seed, epsilon in product(total_budgets, op_budget_ratios, seeds, epsilon_sets):
            scenario = ScenarioConfig(
                name="Geneva",
                demand_config=DemandConfig(
                    seed=seed,
                    demand_periods=T,
                    period_weights=period_weights,
                    split_method="multinomial",
                    # 如果你 DemandConfig 里还有 demand_type 等字段，也可以在这里补上
                ),
                budget_config=BudgetConfig(
                    total_budget=bud,
                    op_budget_ratio=op_ratio,
                )
            )
            instance = InstanceGenerator(scenario)
            instance.build_realistic_scenario()
            instance.save_to_file("h3_instances_json")
            # main_verify_alns(instance, epsilon)
            main_run_single_instance(instance, epsilon, solve_mode="integrated")
            # main_run_single_instance(instance, epsilon, solve_mode="sequential")
            # main_run_single_instance(instance, epsilon, solve_mode="benders")


if __name__ == '__main__':
    # single test
    config = generate_h3_instances()

    # ── Correctness verification (recommended first run) ────────────────────
    # Runs:  integrated MIP  →  LP-oracle sanity check  →  ALNS + stage-2 MIP
    # and prints a full quality-gap table.  Uncomment to enable.
    # main_verify_alns(config, epsilon=EPSILON)

    # ── Individual solve modes ───────────────────────────────────────────────
    main_run_single_instance(config, epsilon=EPSILON, solve_mode="integrated")
    # main_run_single_instance(config, epsilon=EPSILON, solve_mode="alns")
    # main_run_single_instance(config, epsilon=EPSILON, solve_mode="benders")

    # ── Side-by-side comparison of exact methods ─────────────────────────────
    # main_compare_methods(config, epsilon=EPSILON,
    #                      methods=("integrated", "sequential", "benders"))

    # batch test
    # batch_h3_instances()

    # if len(sys.argv) < 2:
    #     print("Please provide instance file path")
    #     sys.exit(1)
    # instance_file = sys.argv[1]  # 命令行里传给 Python 脚本的“第一个参数”（要解的是哪一个 instance 文件）
    # main(instance_file)